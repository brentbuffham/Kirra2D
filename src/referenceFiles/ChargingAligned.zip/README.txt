KIRRA CHARGING CONFIGURATION TEMPLATE
======================================

This ZIP contains CSV template files for configuring Kirra's charging system.
Edit these files in any spreadsheet (Excel, Google Sheets, LibreOffice) or text editor.

FILES:
  products.csv       - Define blast products (explosives, stemming, detonators, etc.)
  chargeConfigs.csv  - Define charge rule configurations

INSTRUCTIONS:
  1. Open each CSV file
  2. Fill in rows below the header (DO NOT modify the header row)
  3. Save as CSV (comma-separated)
  4. Re-ZIP all files together
  5. Import the ZIP into Kirra via File > Import Charging Config

PRODUCT CATEGORIES:
  NonExplosive    - Air, Water, Stemming, StemGel, DrillCuttings
  BulkExplosive   - ANFO, BlendGassed, BlendNonGassed, Emulsion, Molecular
  HighExplosive   - Booster, PackagedEmulsion, CastBooster, Pentolite
  Initiator       - Electronic, ShockTube, Electric, DetonatingCord
  Spacer          - GasBag, StemCap, StemBrush, StemPlug, StemLock

INITIATOR TYPES:
  Electronic       - Programmable delay (set minDelayMs, maxDelayMs, delayIncrementMs)
  ShockTube        - Fixed delay series (set delaySeriesMs as semicolon-separated: 17;25;42;65)
  Electric         - Fixed delay numbers (set delaySeriesMs)
  DetonatingCord   - Continuous burn (set deliveryVodMs, coreLoadGramsPerMeter)

CHARGE CONFIG CODES:
  SIMPLE_SINGLE    - One stemming deck + one coupled deck + one primer
  STNDVS           - Standard vented stemming (stem + charge + air top)
  STNDFS           - Standard fixed stem (stem + fill rest with explosive)
  AIRDEC           - Air deck design (charge + air separation)
  PRESPL           - Presplit charges (packaged products)
  NOCHG            - Do not charge
  CUSTOM           - User-defined via drag-drop builder

DELIVERY VOD (m/s):
  Electronic       - 0 (instant, speed of electricity)
  ShockTube        - 2000 m/s
  Electric         - 0 (instant, speed of electricity)
  DetonatingCord   - 7000 m/s
  Use 0 for instant delivery (no downhole burn time added)

NOTES:
  - Leave cells blank for optional/not-applicable fields
  - Density is in g/cc (grams per cubic centimeter)
  - Lengths/diameters in millimeters unless noted otherwise
  - Boolean fields: use true or false
